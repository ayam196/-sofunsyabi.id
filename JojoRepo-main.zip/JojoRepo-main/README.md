#### Deploy Ke Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/GetSya/JojoRepo)

---------
## FOR TERMUX
- $termux-setup-storage
- $pkg update && pkg upgrade
- $apt-get upgrade
- $apt-get update
- $pkg install imagemagick -y
- $pkg install git -y
- $pkg install nodejs -y
- $pkg install bash
- $pkg install ffmpeg -y
- $git clone https://github.com/GetSya/Jojo-Github
- $cd Jojo-Github
- $bash install.sh
- $npm i multistream
- $npm i fake-useragent
- $npm start

---------

## FOR WINDOWS/VPS/RDP

* Download Dan Install Git [`Klik Disini`](https://git-scm.com/downloads)
* Download Dan Install NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Download Dan Install FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Atur Settingan Path Ffmpeg**)
* Download Dan Install ImageMagick [`Klik Disini`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/GetSya/Jojo-Github
cd Jojo-Github
npm install
npm i imgbb-uploader
npm i multistream
npm i fake-useragent
npm update
```

---------

## Run

```node main.js```

---------

## FITUR
Keterangan!
- Aktif : ✔️
- Ragu Ragu : 🏃
- Gak Aktif : ❌
## OWNER MENU
| | |
| :--- | :--- |
| Addbadword | ✔️ |
| DelBadword | ✔️ |
| ListBadword | ✔️ |
| Addprem | ✔️ |
| Delprem | ✔️ |
| ListPrem | ✔️ |
| Setthumb | ✔️ |
| On | ✔️ |
| Off | ✔️ |
| Addrespon | ✔️ |
| Delrespon | ✔️ |
| Setprefix nopref/multi | ✔️ |
| Set Target | ✔️ |
| Banned | ✔️ |
| Unbanned | ✔️ |
| Setfakeimage | ✔️ |
| Mode | ✔️ |
| Colongsw | ✔️ |
| Read all | ✔️ |
| Eval | ✔️ |
| > | ✔️ |
| $ | ✔️ |
| => | ✔️ |
## GRUPP
| | |
| :--- | :--- |
| Nobadword enable/disable | ✔️ |
| Grup/3 Button | ✔️ |
| Kick | ✔️ |
| Add | ✔️ |
| Get Bio | ✔️ |
| Get Name | ✔️ |
| List Online | ✔️ |
| Group Info | ✔️ |
| Tutup | ✔️ |
| Buka | ✔️ |
| Leave Time | ✔️ |
| Tutup Time | ✔️ |
